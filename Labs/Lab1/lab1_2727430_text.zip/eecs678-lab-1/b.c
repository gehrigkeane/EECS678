#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "simple.h"

void display_onto_stdout(const char *str)
{
	printf("%s\n", str);
}

